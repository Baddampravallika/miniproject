# Connect-Work
it helps to create worker accounts and take the service from the worker.
its created by chunchu manoj

Setup Process
1. download the code as zip file or clone into your system
2. up zip all file in htdocs folder
3. setup your xampp server
4. start mysql server start
5. upload the database user
6. open any browser and type localhost/ConnectWork/

insatll php mailer library in CustomerSignup folder
install php composer and git into your system to access email verification feature

![Connect Work   Sign in (2)](https://github.com/ChunchuManoj/Connect-Work/assets/135858773/20de5919-4f26-47ce-9ad3-16fbddff2249)

login with
email : ramulu123@gmail.com

password : ramulu123

![Connect Work   Workers List](https://github.com/ChunchuManoj/Connect-Work/assets/135858773/22714fab-3169-41ba-8d1a-c96b364bcbb7)
